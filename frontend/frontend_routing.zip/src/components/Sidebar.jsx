import { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { 
  LayoutDashboard, 
  FileText, 
  Users, 
  ClipboardCheck, 
  Settings, 
  LogOut,
  ChevronLeft,
  ChevronRight,
  Award,
  Banknote,
  ShieldCheck,
  UserCircle,
  Bell,
  FileCheck,
  TrendingUp,
  AlertTriangle,
  MapPin,
  Search
} from 'lucide-react';

const Sidebar = ({ user, onLogout, menuItems }) => {
  const navigate = useNavigate();
  const location = useLocation();
  const [isCollapsed, setIsCollapsed] = useState(false);

  const defaultMenuItems = menuItems || [];

  const handleNavigation = (path) => {
    navigate(path);
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    if (onLogout) onLogout();
    navigate('/login');
  };

  const isActive = (path) => {
    return location.pathname === path;
  };

  return (
    <div className={`${isCollapsed ? 'w-20' : 'w-64'} bg-[#1E1B4B] text-white transition-all duration-300 flex flex-col h-screen fixed left-0 top-0 z-50`}>
      
      {/* Header */}
      <div className="p-4 border-b border-white/10">
        <div className="flex items-center justify-between">
          {!isCollapsed && (
            <div className="space-y-3">
              {/* Institution Logos */}
              <div className="flex items-center gap-2">
                <a href="https://www.ipb.ac.id/" target="_blank" rel="noopener noreferrer">
                  <img 
                    src="https://www.ipb.ac.id/wp-content/uploads/2023/12/Logo-IPB-University_Horizontal.png" 
                    alt="IPB" 
                    className="h-8 object-contain bg-white rounded px-1"
                  />
                </a>
                <a href="https://www.unikom.ac.id/" target="_blank" rel="noopener noreferrer">
                  <img 
                    src="/UNIKOM-LOGO-2025-High-Resolution-2048x2048.webp" 
                    alt="UNIKOM" 
                    className="h-8 w-8 object-contain bg-white rounded"
                  />
                </a>
                <a href="#" target="_blank" rel="noopener noreferrer">
                  <img 
                    src="/batap.jpg" 
                    alt="BATAP" 
                    className="h-8 w-8 object-contain rounded"
                  />
                </a>
              </div>
              <div>
                <h1 className="text-lg font-bold text-white tracking-tight">
                  LAM-TEK 2025
                </h1>
                <p className="text-[10px] text-indigo-200 font-medium tracking-wide uppercase">Blockchain Accreditation</p>
              </div>
            </div>
          )}
          <button
            onClick={() => setIsCollapsed(!isCollapsed)}
            className="p-2 rounded-lg hover:bg-white/10 transition-colors"
          >
            {isCollapsed ? (
              <ChevronRight className="w-5 h-5 text-indigo-200" />
            ) : (
              <ChevronLeft className="w-5 h-5 text-indigo-200" />
            )}
          </button>
        </div>
      </div>

      {/* User Profile */}
      <div className="p-4 border-b border-white/10">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-indigo-500 flex items-center justify-center flex-shrink-0">
            <UserCircle className="w-6 h-6 text-white" />
          </div>
          {!isCollapsed && (
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold text-white truncate">
                {user?.fullName || user?.username || 'User'}
              </p>
              <p className="text-xs text-indigo-200 capitalize truncate">
                {user?.role || 'Role'}
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Navigation Menu */}
      <nav className="flex-1 overflow-y-auto py-4 px-2">
        <div className="space-y-1">
          {defaultMenuItems.map((item, index) => {
            const Icon = item.icon;
            const active = isActive(item.path);
            
            return (
              <button
                key={index}
                onClick={() => handleNavigation(item.path)}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors duration-200 ${
                  active
                    ? 'bg-indigo-500 text-white font-medium'
                    : 'text-indigo-100 hover:bg-white/5 hover:text-white'
                }`}
                title={isCollapsed ? item.label : ''}
              >
                <Icon className={`w-5 h-5 flex-shrink-0 ${active ? 'text-white' : 'text-indigo-200'}`} />
                {!isCollapsed && (
                  <span className="text-sm">{item.label}</span>
                )}
                {!isCollapsed && item.badge && (
                  <span className="ml-auto px-2 py-0.5 text-xs font-semibold bg-emerald-500 text-white rounded-full">
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </nav>

      {/* Footer Actions */}
      <div className="p-4 border-t border-white/10 space-y-2">
        <button
          onClick={() => handleNavigation('/settings')}
          className="w-full flex items-center gap-3 px-4 py-3 rounded-lg text-indigo-100 hover:bg-white/5 hover:text-white transition-colors duration-200"
          title={isCollapsed ? 'Settings' : ''}
        >
          <Settings className="w-5 h-5 flex-shrink-0 text-indigo-200" />
          {!isCollapsed && <span className="text-sm">Pengaturan</span>}
        </button>
        
        <button
          onClick={handleLogout}
          className="w-full flex items-center gap-3 px-4 py-3 rounded-lg text-emerald-400 hover:bg-white/5 transition-colors duration-200"
          title={isCollapsed ? 'Logout' : ''}
        >
          <LogOut className="w-5 h-5 flex-shrink-0" />
          {!isCollapsed && <span className="text-sm font-medium">Keluar</span>}
        </button>
      </div>
    </div>
  );
};

// Menu presets for different roles
export const getMenuForRole = (role) => {
  const menus = {
    upps: [
      { icon: LayoutDashboard, label: 'Dashboard', path: '/' },
      { icon: Banknote, label: 'Pembayaran', path: '/upps/payment' },
      { icon: FileText, label: 'Submission Saya', path: '/submissions' },
      { icon: ClipboardCheck, label: 'Status Akreditasi', path: '/status' },
      { icon: Users, label: 'Persetujuan Asesor', path: '/upps/assignments' },
      { icon: MapPin, label: 'Jadwal AL', path: '/upps/al-response' },
      { icon: Users, label: 'Info Asesor', path: '/assessors-info' },
      { icon: Bell, label: 'Notifikasi', path: '/notifications', badge: 0 },
      { icon: Search, label: 'Traceability Sertifikat', path: '/traceability' },
    ],
    sekretariat: [
      { icon: LayoutDashboard, label: 'Dashboard', path: '/sekretariat' },
      { icon: FileCheck, label: 'Verifikasi Dokumen', path: '/sekretariat/verify' },
      { icon: Users, label: 'Manajemen UPPS', path: '/sekretariat/upps' },
      { icon: Banknote, label: 'Verifikasi Pembayaran', path: '/sekretariat/payment' },
      { icon: Award, label: 'Verifikasi Jadwal AL', path: '/sekretariat/al-approval' },
      { icon: TrendingUp, label: 'Laporan', path: '/sekretariat/reports' },
    ],
    kea: [
      { icon: LayoutDashboard, label: 'Dashboard', path: '/kea' },
      { icon: Users, label: 'Penugasan Asesor', path: '/kea/assignments' },
      { icon: AlertTriangle, label: 'Review Penolakan', path: '/kea/rejection-review' },
      { icon: ClipboardCheck, label: 'Monitoring AK', path: '/kea/monitoring' },
      { icon: TrendingUp, label: 'Analisis Konsistensi', path: '/kea/consistency' },
      { icon: Award, label: 'Penjadwalan AL', path: '/kea/al-scheduling' },
      { icon: FileText, label: 'Data Asesor', path: '/kea/assessors' },
    ],
    asesor: [
      { icon: LayoutDashboard, label: 'Dashboard', path: '/asesor' },
      { icon: ClipboardCheck, label: 'Penugasan Saya', path: '/asesor/assignments' },
      { icon: FileText, label: 'Riwayat Penilaian', path: '/asesor/history' },
      { icon: Bell, label: 'Notifikasi', path: '/asesor/notifications', badge: 0 },
    ],
    assessor: [
      { icon: LayoutDashboard, label: 'Dashboard', path: '/assessor' },
      { icon: ClipboardCheck, label: 'Penilaian', path: '/assessor/scoring' },
      { icon: FileText, label: 'Riwayat', path: '/assessor/history' },
    ],
    admin: [
      { icon: LayoutDashboard, label: 'Dashboard', path: '/' },
      { icon: Users, label: 'Manajemen User', path: '/admin/users' },
      { icon: ShieldCheck, label: 'Batch Akreditasi', path: '/admin/batches' },
      { icon: TrendingUp, label: 'Analytics', path: '/admin/analytics' },
      { icon: Settings, label: 'Sistem', path: '/admin/system' },
    ],
    majelis: [
      { icon: LayoutDashboard, label: 'Dashboard', path: '/majelis' },
      { icon: Award, label: 'Keputusan Akreditasi', path: '/majelis/decisions' },
    ],
  };

  // Update KEA menu to include Verification
  if (menus.kea) {
     const hasVerification = menus.kea.find(m => m.path === '/verification');
     if (!hasVerification) {
        // Insert after AL Scheduling
        const alIndex = menus.kea.findIndex(m => m.path === '/kea/al-scheduling');
        if (alIndex !== -1) {
            menus.kea.splice(alIndex + 1, 0, { icon: FileCheck, label: 'Verifikasi Hasil AL', path: '/verification' });
        } else {
            menus.kea.push({ icon: FileCheck, label: 'Verifikasi Hasil AL', path: '/verification' });
        }
     }
  }

  // Update Sekretariat menu to include Release
  if (menus.sekretariat) {
      const hasRelease = menus.sekretariat.find(m => m.path === '/release');
      if (!hasRelease) {
          menus.sekretariat.push({ icon: Award, label: 'Rilis Sertifikat', path: '/release' });
      }
  }

  return menus[role] || menus.upps;
};

export default Sidebar;
